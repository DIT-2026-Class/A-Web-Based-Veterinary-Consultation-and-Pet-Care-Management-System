import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, FileHeart, Search } from "lucide-react";
import { toast } from "sonner";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { PageHeader, SectionCard } from "@/components/dashboard/Primitives";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { LoadingState } from "@/components/ui/loading-state";
import { useMedicalRecords } from "@/hooks/use-medical-records";
import type { MedicalRecordView } from "@/lib/api/medical-records";

export const Route = createFileRoute("/dashboard/records")({
  ssr: false,
  head: () => ({ meta: [{ title: "Health Records — VetCare Ghana" }] }),
  component: RecordsPage,
});

function RecordsPage() {
  return (
    <RequireAuth role="owner">
      <RecordsContent />
    </RequireAuth>
  );
}

function RecordsContent() {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<MedicalRecordView | null>(null);
  const { data: medicalRecords = [], isLoading } = useMedicalRecords();

  if (isLoading) {
    return (
      <DashboardLayout role="owner">
        <LoadingState />
      </DashboardLayout>
    );
  }

  const filtered = medicalRecords.filter(
    (r) =>
      r.petName.toLowerCase().includes(query.toLowerCase()) ||
      r.diagnosis.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <DashboardLayout role="owner">
      <div className="space-y-6">
        <PageHeader
          title="Digital Health Records"
          subtitle="Search, view, and download your pets' complete medical history."
          action={
            <Button variant="outline" onClick={() => toast.success("Records exported as PDF")}>
              <Download className="h-4 w-4" /> Export All
            </Button>
          }
        />

        <SectionCard>
          <div className="relative mb-4 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search records..." className="pl-9" />
          </div>

          {filtered.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">No medical records found.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pet</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Diagnosis</TableHead>
                    <TableHead>Vet</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((r) => (
                    <TableRow key={r.id} className="cursor-pointer" onClick={() => setActive(r)}>
                      <TableCell className="font-semibold">{r.petName}</TableCell>
                      <TableCell>
                        <StatusBadge tone={r.status}>{r.type}</StatusBadge>
                      </TableCell>
                      <TableCell className="max-w-[220px] truncate">{r.diagnosis}</TableCell>
                      <TableCell className="text-muted-foreground">{r.vet}</TableCell>
                      <TableCell className="text-muted-foreground">{r.date}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">View</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </SectionCard>
      </div>

      <Sheet open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <SheetContent>
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <FileHeart className="h-5 w-5 text-primary" /> Record Details
            </SheetTitle>
            <SheetDescription>{active?.petName} · {active?.date}</SheetDescription>
          </SheetHeader>
          {active && (
            <div className="mt-6 space-y-4 px-4">
              <div className="rounded-2xl border bg-card p-4">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Diagnosis</p>
                <p className="mt-1 font-semibold">{active.diagnosis}</p>
              </div>
              <div className="rounded-2xl border bg-card p-4">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Record Type</p>
                <p className="mt-1 text-sm">{active.type}</p>
              </div>
              <div className="rounded-2xl border bg-card p-4">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Attending Vet</p>
                <p className="mt-1 text-sm">{active.vet}</p>
              </div>
              <Button variant="hero" className="w-full" onClick={() => toast.success("PDF downloaded")}>
                <Download className="h-4 w-4" /> Download PDF
              </Button>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </DashboardLayout>
  );
}
