import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BookOpen, Search } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Input } from "@/components/ui/input";
import { LoadingState } from "@/components/ui/loading-state";
import { useArticles } from "@/hooks/use-articles";
import { getArticleCategories } from "@/lib/api/articles";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/health-center")({
  head: () => ({
    meta: [
      { title: "Health Information Center — VetCare Ghana" },
      { name: "description", content: "Educational articles, disease prevention resources, and pet care guides for Ghanaian pet owners." },
    ],
  }),
  component: HealthCenterPage,
});

function HealthCenterPage() {
  const [cat, setCat] = useState("All");
  const [query, setQuery] = useState("");
  const { data: articles = [], isLoading } = useArticles();

  const categories = getArticleCategories(articles);

  const filtered = articles.filter(
    (a) =>
      (cat === "All" || a.category === cat) &&
      a.title.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-12">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
            <BookOpen className="h-3.5 w-3.5" /> Health Information Center
          </span>
          <h1 className="mt-4 text-3xl font-extrabold sm:text-4xl">Pet care guides & resources</h1>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Expert-written articles to help you keep your pets healthy and happy.
          </p>
        </div>

        <div className="mx-auto mt-8 max-w-md">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search articles..." className="pl-9" />
          </div>
        </div>

        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={cn(
                "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
                cat === c ? "border-primary bg-primary/10 text-primary" : "hover:bg-accent",
              )}
            >
              {c}
            </button>
          ))}
        </div>

        {isLoading ? (
          <LoadingState />
        ) : filtered.length === 0 ? (
          <p className="mt-10 text-center text-muted-foreground">No articles found.</p>
        ) : (
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((a) => (
              <article key={a.id} className="hover-lift overflow-hidden rounded-2xl border bg-card shadow-sm">
                <img src={a.image} alt={a.title} className="h-44 w-full object-cover" loading="lazy" />
                <div className="p-5">
                  <span className="text-xs font-semibold uppercase tracking-wide text-primary">{a.category}</span>
                  <h2 className="mt-2 font-bold leading-snug">{a.title}</h2>
                  <p className="mt-2 text-sm text-muted-foreground">{a.excerpt}</p>
                  <p className="mt-4 text-xs text-muted-foreground">{a.readTime}</p>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
