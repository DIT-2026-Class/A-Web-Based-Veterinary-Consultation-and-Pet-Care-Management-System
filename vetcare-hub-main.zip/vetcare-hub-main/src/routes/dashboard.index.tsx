import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Bell,
  CalendarPlus,
  FileHeart,
  PawPrint,
  Pill,
  Plus,
  Stethoscope,
  TriangleAlert,
  Video,
} from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { StatCard } from "@/components/dashboard/StatCard";
import { SectionCard } from "@/components/dashboard/Primitives";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { LoadingState } from "@/components/ui/loading-state";
import { useAuth } from "@/lib/auth";
import { usePets } from "@/hooks/use-pets";
import { useOwnerAppointments } from "@/hooks/use-appointments";
import { useNotifications } from "@/hooks/use-notifications";
import { useMedicalRecords } from "@/hooks/use-medical-records";
import { formatRelative } from "@/lib/format";
import type { StatusTone } from "@/lib/status";

export const Route = createFileRoute("/dashboard/")({
  ssr: false,
  head: () => ({ meta: [{ title: "Dashboard — VetCare Ghana" }] }),
  component: OwnerDashboard,
});

const quickActions = [
  { label: "Book Appointment", icon: CalendarPlus, to: "/dashboard/appointments" },
  { label: "Add a Pet", icon: Plus, to: "/dashboard/pets" },
  { label: "Start Consultation", icon: Video, to: "/dashboard/consultation" },
  { label: "Find a Vet", icon: Stethoscope, to: "/find-vet" },
];

function OwnerDashboard() {
  return (
    <RequireAuth role="owner">
      <DashboardContent />
    </RequireAuth>
  );
}

function DashboardContent() {
  const { profile } = useAuth();
  const { data: pets = [], isLoading: petsLoading } = usePets();
  const { data: appointments = [], isLoading: apptsLoading } = useOwnerAppointments();
  const { data: notifications = [] } = useNotifications();
  const { data: records = [] } = useMedicalRecords();

  if (petsLoading || apptsLoading) {
    return (
      <DashboardLayout role="owner">
        <LoadingState />
      </DashboardLayout>
    );
  }

  const upcoming = appointments.filter((a) => a.status === "upcoming");
  const healthAlerts = pets.filter((p) => p.healthStatus === "warning" || p.healthStatus === "error").length;
  const prescriptions = records.filter((r) => r.type.toLowerCase().includes("prescription")).length;

  const activities = [
    ...records.slice(0, 2).map((r) => ({
      icon: FileHeart,
      text: `${r.type} for ${r.petName} — ${r.diagnosis}`,
      time: formatRelative(r.recordDate),
      tone: r.status as StatusTone,
    })),
    ...appointments.slice(0, 2).map((a) => ({
      icon: CalendarPlus,
      text: `${a.type} with ${a.vet}`,
      time: a.scheduledAt ? formatRelative(a.scheduledAt) : "",
      tone: "info" as StatusTone,
    })),
  ].slice(0, 4);

  return (
    <DashboardLayout role="owner">
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-3xl bg-gradient-primary p-6 text-primary-foreground shadow-glow sm:p-8"
        >
          <div className="pointer-events-none absolute -right-10 -top-10 h-48 w-48 rounded-full bg-background/10 blur-2xl" />
          <p className="text-sm font-medium text-primary-foreground/80">Welcome back 👋</p>
          <h1 className="mt-1 text-2xl font-extrabold sm:text-3xl">{profile?.full_name ?? "Pet Owner"}</h1>
          <p className="mt-2 max-w-md text-sm text-primary-foreground/90">
            {pets.length > 0
              ? `You have ${upcoming.length} upcoming appointment${upcoming.length !== 1 ? "s" : ""} this week.`
              : "Add your first pet to start tracking their health."}
          </p>
          <Button asChild size="lg" className="mt-5 bg-background text-foreground hover:bg-background/90">
            <Link to="/dashboard/appointments">
              <CalendarPlus className="h-5 w-5" /> Book Appointment
            </Link>
          </Button>
        </motion.div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Total Pets" value={pets.length} icon={PawPrint} tone="primary" index={0} />
          <StatCard label="Upcoming Appointments" value={upcoming.length} icon={CalendarPlus} tone="info" index={1} />
          <StatCard label="Active Prescriptions" value={prescriptions} icon={Pill} tone="success" index={2} />
          <StatCard label="Health Alerts" value={healthAlerts} icon={TriangleAlert} tone="warning" index={3} />
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {quickActions.map((a) => (
            <Link
              key={a.label}
              to={a.to}
              className="hover-lift flex items-center gap-3 rounded-2xl border bg-card p-4 shadow-sm"
            >
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                <a.icon className="h-5 w-5" />
              </span>
              <span className="text-sm font-semibold">{a.label}</span>
            </Link>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <SectionCard
              title="Upcoming Appointments"
              action={
                <Button asChild variant="ghost" size="sm">
                  <Link to="/dashboard/appointments">View all</Link>
                </Button>
              }
            >
              <div className="space-y-3">
                {upcoming.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No upcoming appointments.</p>
                ) : (
                  upcoming.map((a) => (
                    <div key={a.id} className="flex items-center gap-3 rounded-xl border p-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={a.petPhoto} alt={a.petName} />
                        <AvatarFallback>{a.petName[0]}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{a.type}</p>
                        <p className="truncate text-xs text-muted-foreground">
                          {a.petName} · {a.vet}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold">{a.date}</p>
                        <p className="text-xs text-muted-foreground">{a.time}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </SectionCard>

            <SectionCard title="Recent Activity">
              {activities.length === 0 ? (
                <p className="text-sm text-muted-foreground">No recent activity yet.</p>
              ) : (
                <ul className="space-y-4">
                  {activities.map((act, i) => (
                    <li key={i} className="flex gap-3">
                      <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-muted text-muted-foreground">
                        <act.icon className="h-4 w-4" />
                      </span>
                      <div className="flex-1">
                        <p className="text-sm">{act.text}</p>
                        <p className="text-xs text-muted-foreground">{act.time}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </SectionCard>
          </div>

          <div className="space-y-6">
            <SectionCard title="Notifications" action={<Bell className="h-4 w-4 text-muted-foreground" />}>
              <div className="space-y-3">
                {notifications.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No notifications.</p>
                ) : (
                  notifications.map((n) => (
                    <div key={n.id} className="rounded-xl border p-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-semibold">{n.title}</p>
                        {!n.read && <StatusBadge tone={n.tone}>New</StatusBadge>}
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">{n.desc}</p>
                    </div>
                  ))
                )}
              </div>
            </SectionCard>

            <SectionCard
              title="My Pets"
              action={
                <Button asChild variant="ghost" size="sm">
                  <Link to="/dashboard/pets">Manage</Link>
                </Button>
              }
            >
              <div className="space-y-3">
                {pets.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No pets yet. Add your first pet!</p>
                ) : (
                  pets.map((p) => (
                    <Link
                      key={p.id}
                      to="/dashboard/pets"
                      className="flex items-center gap-3 rounded-xl border p-3 transition-colors hover:bg-accent"
                    >
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={p.photo} alt={p.name} />
                        <AvatarFallback>{p.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-sm font-semibold">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{p.breed}</p>
                      </div>
                      <StatusBadge tone={p.healthStatus}>{p.healthLabel}</StatusBadge>
                    </Link>
                  ))
                )}
              </div>
            </SectionCard>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
