import { createFileRoute } from "@tanstack/react-router";
import { Award, GraduationCap, Loader2, Star } from "lucide-react";
import { toast } from "sonner";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { PageHeader, SectionCard } from "@/components/dashboard/Primitives";
import { StatusBadge } from "@/components/ui/status-badge";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { LoadingState } from "@/components/ui/loading-state";
import { useCurrentVet, useUpdateVet } from "@/hooks/use-vets";

export const Route = createFileRoute("/vet/profile")({
  ssr: false,
  head: () => ({ meta: [{ title: "My Profile — VetCare Ghana" }] }),
  component: VetProfilePage,
});

function VetProfilePage() {
  return (
    <RequireAuth role="vet">
      <VetProfileContent />
    </RequireAuth>
  );
}

function VetProfileContent() {
  const { data: vet, isLoading } = useCurrentVet();
  const updateVet = useUpdateVet();

  if (isLoading) {
    return (
      <DashboardLayout role="vet">
        <LoadingState />
      </DashboardLayout>
    );
  }

  if (!vet) {
    return (
      <DashboardLayout role="vet">
        <p className="text-muted-foreground">Vet profile not found. Please contact support.</p>
      </DashboardLayout>
    );
  }

  const handleAvailabilityToggle = async (available: boolean) => {
    try {
      await updateVet.mutateAsync({ id: vet.id, updates: { available } });
      toast.success(available ? "You are now available" : "You are now unavailable");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Update failed");
    }
  };

  return (
    <DashboardLayout role="vet">
      <div className="space-y-6">
        <PageHeader title="My Profile" subtitle="Manage your professional details and availability." />

        <div className="grid gap-6 lg:grid-cols-3">
          <SectionCard className="text-center">
            <Avatar className="mx-auto h-24 w-24">
              <AvatarImage src={vet.photo} alt={vet.name} />
              <AvatarFallback>{vet.name[0]}</AvatarFallback>
            </Avatar>
            <h2 className="mt-4 text-lg font-bold">{vet.name}</h2>
            <p className="text-sm text-primary">{vet.specialization}</p>
            <div className="mt-2 flex items-center justify-center gap-1 text-sm">
              <Star className="h-4 w-4 fill-warning text-warning" />
              <span className="font-semibold">{vet.rating}</span>
              <span className="text-muted-foreground">({vet.reviews} reviews)</span>
            </div>
            <StatusBadge tone={vet.available ? "success" : "warning"} className="mt-3">
              {vet.available ? "Available" : "Unavailable"}
            </StatusBadge>
          </SectionCard>

          <div className="space-y-6 lg:col-span-2">
            <SectionCard title="Qualifications & Experience">
              <ul className="space-y-3 text-sm">
                <li className="flex items-center gap-3">
                  <GraduationCap className="h-5 w-5 text-primary" /> {vet.specialization}
                </li>
                <li className="flex items-center gap-3">
                  <Award className="h-5 w-5 text-primary" /> {vet.experience} of clinical experience
                </li>
                <li className="flex items-center gap-3">
                  <Star className="h-5 w-5 text-primary" /> Consultation fee: GHS {vet.consultationFee}
                </li>
                {vet.bio && (
                  <li className="text-muted-foreground">{vet.bio}</li>
                )}
              </ul>
            </SectionCard>

            <SectionCard title="Availability Settings">
              <div className="flex items-center justify-between rounded-xl border p-4">
                <div>
                  <p className="text-sm font-medium">Accepting appointments</p>
                  <p className="text-xs text-muted-foreground">
                    Toggle your availability for new bookings
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {updateVet.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                  <Switch
                    checked={vet.available}
                    onCheckedChange={handleAvailabilityToggle}
                    aria-label="Toggle availability"
                  />
                </div>
              </div>
            </SectionCard>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
