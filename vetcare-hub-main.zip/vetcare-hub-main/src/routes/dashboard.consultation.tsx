import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mic, MicOff, Paperclip, Phone, Pill, Send, Video, VideoOff } from "lucide-react";
import { toast } from "sonner";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { SectionCard } from "@/components/dashboard/Primitives";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { useAuth } from "@/lib/auth";
import { useOwnerAppointments, useVetAppointments } from "@/hooks/use-appointments";
import { photoOrDefault } from "@/lib/format";

export const Route = createFileRoute("/dashboard/consultation")({
  ssr: false,
  head: () => ({ meta: [{ title: "Virtual Consultation — VetCare Ghana" }] }),
  component: ConsultationPage,
});

function ConsultationPage() {
  return (
    <RequireAuth role={["owner", "vet"]}>
      <ConsultationContent />
    </RequireAuth>
  );
}

function ConsultationContent() {
  const { role, profile } = useAuth();
  const dashRole = role === "vet" ? "vet" : "owner";
  const { data: ownerAppts = [] } = useOwnerAppointments();
  const { data: vetAppts = [] } = useVetAppointments();
  const appointments = role === "vet" ? vetAppts : ownerAppts;

  const activeAppt = appointments.find((a) => a.status === "upcoming" || a.status === "in-progress");
  const vetPhoto = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=900&q=80";
  const userPhoto = photoOrDefault(profile?.avatar_url);

  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [messages, setMessages] = useState<{ me: boolean; text: string }[]>([]);
  const [draft, setDraft] = useState("");
  const [notes, setNotes] = useState(activeAppt?.notes ?? "");

  return (
    <DashboardLayout role={dashRole}>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {activeAppt ? (
            <p className="text-sm text-muted-foreground">
              Consultation with {role === "vet" ? activeAppt.petName : activeAppt.vet} · {activeAppt.type} · {activeAppt.date} {activeAppt.time}
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">No active consultation. Book an appointment to start.</p>
          )}

          <div className="relative aspect-video overflow-hidden rounded-2xl bg-foreground shadow-soft">
            <img
              src={role === "vet" ? photoOrDefault(activeAppt?.petPhoto) : vetPhoto}
              alt="Consultation participant"
              className="h-full w-full object-cover"
            />
            <div className="absolute right-4 top-4 h-28 w-40 overflow-hidden rounded-xl border-2 border-background/40 bg-background/20 backdrop-blur">
              <img src={userPhoto} alt="You" className="h-full w-full object-cover" />
            </div>
            <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-2 rounded-2xl bg-background/80 p-2 backdrop-blur">
              <Button variant={muted ? "destructive" : "secondary"} size="icon" onClick={() => setMuted((v) => !v)} aria-label="Toggle microphone">
                {muted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
              </Button>
              <Button variant={camOff ? "destructive" : "secondary"} size="icon" onClick={() => setCamOff((v) => !v)} aria-label="Toggle camera">
                {camOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
              </Button>
              <Button variant="destructive" size="icon" onClick={() => toast("Call ended")} aria-label="End call">
                <Phone className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <SectionCard title="Consultation Notes">
            <Textarea
              placeholder="Doctor's notes appear here..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          </SectionCard>
        </div>

        <div className="space-y-6">
          <SectionCard title="Chat" className="flex h-[420px] flex-col">
            <div className="flex-1 space-y-3 overflow-y-auto pr-1">
              {messages.length === 0 ? (
                <p className="text-sm text-muted-foreground">Start the conversation...</p>
              ) : (
                messages.map((m, i) => (
                  <div key={i} className={`flex ${m.me ? "justify-end" : "justify-start"}`}>
                    <span className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${m.me ? "bg-gradient-primary text-primary-foreground" : "bg-muted"}`}>
                      {m.text}
                    </span>
                  </div>
                ))
              )}
            </div>
            <form
              className="mt-3 flex items-center gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (!draft.trim()) return;
                setMessages((prev) => [...prev, { me: true, text: draft }]);
                setDraft("");
              }}
            >
              <Button type="button" variant="ghost" size="icon" aria-label="Attach file">
                <Paperclip className="h-4 w-4" />
              </Button>
              <Input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Type a message..." />
              <Button type="submit" variant="hero" size="icon" aria-label="Send">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </SectionCard>

          <SectionCard title="Prescription" action={<Pill className="h-4 w-4 text-primary" />}>
            {activeAppt?.notes ? (
              <div className="space-y-2 rounded-xl border p-3 text-sm">
                <p className="font-semibold">From consultation notes</p>
                <p className="text-muted-foreground">{activeAppt.notes}</p>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No prescription yet.</p>
            )}
            <Button variant="outline" className="mt-3 w-full" onClick={() => toast.success("Prescription downloaded")}>
              Download Prescription
            </Button>
          </SectionCard>
        </div>
      </div>
    </DashboardLayout>
  );
}
