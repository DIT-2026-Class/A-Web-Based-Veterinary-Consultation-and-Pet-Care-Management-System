import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CalendarPlus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { PageHeader, SectionCard } from "@/components/dashboard/Primitives";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { LoadingState } from "@/components/ui/loading-state";
import { useOwnerAppointments, useCreateAppointment } from "@/hooks/use-appointments";
import { usePets } from "@/hooks/use-pets";
import { useVets } from "@/hooks/use-vets";
import type { StatusTone } from "@/lib/status";

export const Route = createFileRoute("/dashboard/appointments")({
  ssr: false,
  head: () => ({ meta: [{ title: "Appointments — VetCare Ghana" }] }),
  component: AppointmentsPage,
});

const statusTone: Record<string, { tone: StatusTone; label: string }> = {
  upcoming: { tone: "info", label: "Upcoming" },
  completed: { tone: "success", label: "Completed" },
  cancelled: { tone: "error", label: "Cancelled" },
  "in-progress": { tone: "warning", label: "In Progress" },
};

const slots = ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"];

function AppointmentsPage() {
  return (
    <RequireAuth role="owner">
      <AppointmentsContent />
    </RequireAuth>
  );
}

function AppointmentsContent() {
  const [open, setOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [selectedSlot, setSelectedSlot] = useState("10:00");
  const [petId, setPetId] = useState("");
  const [vetId, setVetId] = useState("");
  const { data: appointments = [], isLoading } = useOwnerAppointments();
  const { data: pets = [] } = usePets();
  const { data: vets = [] } = useVets();
  const createAppointment = useCreateAppointment();

  if (isLoading) {
    return (
      <DashboardLayout role="owner">
        <LoadingState />
      </DashboardLayout>
    );
  }

  const upcoming = appointments.filter((a) => a.status === "upcoming");

  return (
    <DashboardLayout role="owner">
      <div className="space-y-6">
        <PageHeader
          title="Appointments"
          subtitle="Book visits, view availability, and track appointment history."
          action={
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button variant="hero">
                  <CalendarPlus className="h-4 w-4" /> Book Appointment
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Book an appointment</DialogTitle>
                  <DialogDescription>Select a pet, vet, date, and time.</DialogDescription>
                </DialogHeader>
                <form
                  className="space-y-4"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const form = new FormData(e.currentTarget);
                    const type = form.get("type") as string;
                    if (!petId || !vetId) {
                      toast.error("Please select a pet and veterinarian");
                      return;
                    }
                    const scheduledAt = new Date(`${selectedDate}T${selectedSlot}:00`).toISOString();

                    try {
                      await createAppointment.mutateAsync({ petId, vetId, type, scheduledAt });
                      setOpen(false);
                      toast.success("Appointment booked!");
                    } catch (err) {
                      toast.error(err instanceof Error ? err.message : "Booking failed");
                    }
                  }}
                >
                  <div className="space-y-2">
                    <Label>Pet</Label>
                    <Select value={petId} onValueChange={setPetId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select pet" />
                      </SelectTrigger>
                      <SelectContent>
                        {pets.map((p) => (
                          <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Veterinarian</Label>
                    <Select value={vetId} onValueChange={setVetId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select vet" />
                      </SelectTrigger>
                      <SelectContent>
                        {vets.filter((v) => v.available).map((v) => (
                          <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Appointment type</Label>
                    <Input id="type" name="type" placeholder="Annual checkup" required />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="date">Date</Label>
                      <Input
                        id="date"
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Time</Label>
                      <Select value={selectedSlot} onValueChange={setSelectedSlot}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {slots.map((s) => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" variant="hero" className="w-full" disabled={createAppointment.isPending}>
                      {createAppointment.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                      Confirm Booking
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          }
        />

        <div className="grid gap-6 lg:grid-cols-3">
          <SectionCard title="Available Time Slots" className="lg:col-span-2">
            <div className="mt-3 flex flex-wrap gap-2">
              {slots.map((s) => (
                <button
                  key={s}
                  onClick={() => {
                    setSelectedSlot(s);
                    toast.success(`Slot ${s} selected`);
                  }}
                  className={`rounded-xl border px-4 py-2 text-sm font-medium transition-colors ${
                    selectedSlot === s
                      ? "border-primary bg-primary/10 text-primary"
                      : "hover:border-primary hover:bg-primary/10 hover:text-primary"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="This Week">
            <div className="space-y-3">
              {upcoming.length === 0 ? (
                <p className="text-sm text-muted-foreground">No upcoming appointments.</p>
              ) : (
                upcoming.map((a) => (
                  <div key={a.id} className="rounded-xl border p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold">{a.type}</p>
                      <StatusBadge tone="info">{a.time}</StatusBadge>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {a.petName} · {a.date}
                    </p>
                  </div>
                ))
              )}
            </div>
          </SectionCard>
        </div>

        <SectionCard>
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="completed">History</TabsTrigger>
            </TabsList>
            {(["all", "upcoming", "completed"] as const).map((tab) => (
              <TabsContent key={tab} value={tab} className="mt-4 space-y-3">
                {appointments
                  .filter((a) =>
                    tab === "all" ? true : tab === "completed" ? a.status !== "upcoming" : a.status === "upcoming",
                  )
                  .map((a) => (
                    <div key={a.id} className="flex items-center gap-3 rounded-xl border p-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={a.petPhoto} alt={a.petName} />
                        <AvatarFallback>{a.petName[0]}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{a.type}</p>
                        <p className="truncate text-xs text-muted-foreground">
                          {a.petName} · {a.vet} · {a.date} {a.time}
                        </p>
                      </div>
                      <StatusBadge tone={statusTone[a.status]?.tone ?? "muted"}>
                        {statusTone[a.status]?.label ?? a.status}
                      </StatusBadge>
                    </div>
                  ))}
                {appointments.filter((a) =>
                  tab === "all" ? true : tab === "completed" ? a.status !== "upcoming" : a.status === "upcoming",
                ).length === 0 && (
                  <p className="text-sm text-muted-foreground">No appointments in this category.</p>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </SectionCard>
      </div>
    </DashboardLayout>
  );
}
