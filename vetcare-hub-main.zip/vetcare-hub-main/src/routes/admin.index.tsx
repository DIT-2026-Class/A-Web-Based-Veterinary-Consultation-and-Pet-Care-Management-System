import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays, ShieldCheck, Stethoscope, Users } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { toast } from "sonner";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { StatCard } from "@/components/dashboard/StatCard";
import { SectionCard } from "@/components/dashboard/Primitives";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { LoadingState } from "@/components/ui/loading-state";
import { useAdminStats } from "@/hooks/use-admin";
import { useVets, useToggleVetAvailability } from "@/hooks/use-vets";

export const Route = createFileRoute("/admin/")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>) => ({
    view: typeof search.view === "string" ? search.view : undefined,
  }),
  head: () => ({ meta: [{ title: "Admin Dashboard — VetCare Ghana" }] }),
  component: AdminDashboard,
});

function AdminDashboard() {
  return (
    <RequireAuth role="admin">
      <AdminDashboardContent />
    </RequireAuth>
  );
}

function AdminDashboardContent() {
  const { view } = Route.useSearch();
  const { data: stats, isLoading: statsLoading } = useAdminStats();
  const { data: vets = [], isLoading: vetsLoading } = useVets();
  const toggleAvailability = useToggleVetAvailability();

  useEffect(() => {
    if (!view) return;
    const target = view === "users" || view === "verification" ? "verification" : view;
    const el = document.getElementById(`admin-${target}`);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [view, statsLoading, vetsLoading]);

  if (statsLoading || vetsLoading) {
    return (
      <DashboardLayout role="admin">
        <LoadingState />
      </DashboardLayout>
    );
  }


  const handleVerify = async (vetId: string, available: boolean) => {
    try {
      await toggleAvailability.mutateAsync({ id: vetId, available });
      toast.success(available ? "Vet verified" : "Vet marked as pending");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    }
  };

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        <h1 className="text-2xl font-extrabold sm:text-3xl">Platform Overview</h1>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Total Users" value={stats?.totalUsers ?? 0} icon={Users} tone="primary" index={0} />
          <StatCard label="Active Vets" value={stats?.activeVets ?? 0} icon={Stethoscope} tone="info" index={1} />
          <StatCard label="Appointments (mo)" value={stats?.appointmentsThisMonth ?? 0} icon={CalendarDays} tone="success" index={2} />
          <StatCard label="Pending Verifications" value={stats?.pendingVerifications ?? 0} icon={ShieldCheck} tone="warning" index={3} />
        </div>

        <div id="admin-analytics">
          <SectionCard title="User Growth">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats?.userGrowth ?? []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="m" stroke="var(--color-muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 12,
                    }}
                  />
                  <Bar dataKey="users" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </SectionCard>
        </div>
        <div id="admin-verification">
        <SectionCard title="Veterinarian Verification">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Veterinarian</TableHead>
                  <TableHead>Specialization</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {vets.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">
                      No veterinarians registered yet.
                    </TableCell>
                  </TableRow>
                ) : (
                  vets.map((v) => (
                    <TableRow key={v.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={v.photo} alt={v.name} />
                            <AvatarFallback>{v.name[0]}</AvatarFallback>
                          </Avatar>
                          <span className="font-semibold">{v.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{v.specialization}</TableCell>
                      <TableCell className="text-muted-foreground">{v.location}</TableCell>
                      <TableCell>
                        <StatusBadge tone={v.available ? "success" : "warning"}>
                          {v.available ? "Verified" : "Pending"}
                        </StatusBadge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleVerify(v.id, !v.available)}
                          disabled={toggleAvailability.isPending}
                        >
                          {v.available ? "Revoke" : "Verify"}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </SectionCard>
        </div>
      </div>
    </DashboardLayout>
  );
}
