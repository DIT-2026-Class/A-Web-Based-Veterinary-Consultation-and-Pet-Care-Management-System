import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Hero } from "@/components/landing/Hero";
import { Features } from "@/components/landing/Features";
import { HowItWorks } from "@/components/landing/HowItWorks";
import { Testimonials } from "@/components/landing/Testimonials";
import { Faq } from "@/components/landing/Faq";
import { CtaBanner } from "@/components/landing/CtaBanner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VetCare Ghana — Veterinary Care Anywhere, Anytime" },
      {
        name: "description",
        content:
          "Book appointments, consult licensed veterinarians online, and manage your pet's complete health records on Ghana's trusted pet healthcare platform.",
      },
      { property: "og:title", content: "VetCare Ghana — Veterinary Care Anywhere, Anytime" },
      {
        property: "og:description",
        content:
          "Online consultations, easy appointment booking, and digital pet health records for pet owners and veterinarians across Ghana.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <Features />
        <HowItWorks />
        <Testimonials />
        <Faq />
        <CtaBanner />
      </main>
      <SiteFooter />
    </div>
  );
}
