import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff, Loader2, PawPrint, Stethoscope } from "lucide-react";
import { toast } from "sonner";
import { AuthShell } from "@/components/auth/AuthShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth";
import { homeForRole } from "@/lib/auth";

export const Route = createFileRoute("/register")({
  head: () => ({ meta: [{ title: "Create account — VetCare Ghana" }] }),
  component: RegisterPage,
});

type Role = "owner" | "vet" | "admin";

function RegisterPage() {
  const [role, setRole] = useState<Role>("owner");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { signUp } = useAuth();

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const first = form.get("first") as string;
    const last = form.get("last") as string;
    const email = form.get("email") as string;
    const password = form.get("password") as string;
    const fullName = `${first} ${last}`.trim();

    setLoading(true);
    try {
      await signUp(fullName, email, password, role);
      toast.success("Account created! Welcome to VetCare.");
      navigate({ to: homeForRole(role) });
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error("Registration error:", err);
      toast.error("Unexpected error during registration.");
    } finally {
      setLoading(false);
    }
  };

  const roles: { id: Role; icon: typeof PawPrint; title: string; desc: string }[] = [
    { id: "owner", icon: PawPrint, title: "Pet Owner", desc: "Manage your pets' health" },
    { id: "vet", icon: Stethoscope, title: "Veterinarian", desc: "Offer care & consultations" },
    { id: "admin", icon: PawPrint, title: "Admin", desc: "Manage the platform and users" },
  ];

  return (
    <AuthShell title="Create your account" subtitle="Join VetCare Ghana in less than a minute.">
      <form onSubmit={onSubmit} className="space-y-5">
        <div className="space-y-2">
          <Label>I am a</Label>
          <div className="grid grid-cols-2 gap-3">
            {roles.map((r) => (
              <button
                type="button"
                key={r.id}
                onClick={() => setRole(r.id)}
                aria-pressed={role === r.id}
                className={cn(
                  "rounded-2xl border p-4 text-left transition-all",
                  role === r.id
                    ? "border-primary bg-primary/5 shadow-glow"
                    : "border-border hover:border-primary/40 hover:bg-accent",
                )}
              >
                <span
                  className={cn(
                    "grid h-10 w-10 place-items-center rounded-xl",
                    role === r.id ? "bg-gradient-primary text-primary-foreground" : "bg-muted text-muted-foreground",
                  )}
                >
                  <r.icon className="h-5 w-5" />
                </span>
                <p className="mt-3 text-sm font-bold">{r.title}</p>
                <p className="text-xs text-muted-foreground">{r.desc}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label htmlFor="first">First name</Label>
            <Input id="first" name="first" placeholder="Ama" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="last">Last name</Label>
            <Input id="last" name="last" placeholder="Mensah" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email address</Label>
          <Input id="email" name="email" type="email" placeholder="you@example.com" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <Input id="password" name="password" type={show ? "text" : "password"} placeholder="••••••••" required minLength={6} />
            <button
              type="button"
              onClick={() => setShow((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label={show ? "Hide password" : "Show password"}
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <Button type="submit" variant="hero" size="lg" className="w-full" disabled={loading}>
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          Create account
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link to="/login" className="font-semibold text-primary hover:underline">
          Log in
        </Link>
      </p>
    </AuthShell>
  );
}