import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PawPrint, Plus, Stethoscope, Syringe, Upload } from "lucide-react";
import { toast } from "sonner";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { PageHeader, SectionCard } from "@/components/dashboard/Primitives";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { LoadingState, EmptyState } from "@/components/ui/loading-state";
import { usePets, useCreatePet } from "@/hooks/use-pets";
import { usePetMedicalRecords, useVaccinationRecords } from "@/hooks/use-medical-records";

export const Route = createFileRoute("/dashboard/pets")({
  ssr: false,
  head: () => ({ meta: [{ title: "My Pets — VetCare Ghana" }] }),
  component: PetsPage,
});

function PetsPage() {
  return (
    <RequireAuth role="owner">
      <PetsContent />
    </RequireAuth>
  );
}

function PetsContent() {
  const [open, setOpen] = useState(false);
  const { data: pets = [], isLoading } = usePets();
  const createPet = useCreatePet();
  const [selectedPetId, setSelectedPetId] = useState<string | undefined>(undefined);

  const activePetId = selectedPetId ?? pets[0]?.id;
  const { data: vaccinations = [] } = useVaccinationRecords(activePetId);
  const { data: medicalHistory = [] } = usePetMedicalRecords(activePetId);
  const selectedPet = pets.find((p) => p.id === activePetId);

  if (isLoading) {
    return (
      <DashboardLayout role="owner">
        <LoadingState />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="owner">
      <div className="space-y-6">
        <PageHeader
          title="My Pets"
          subtitle="Manage profiles, photos, and health history for every pet."
          action={
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button variant="hero">
                  <Plus className="h-4 w-4" /> Add Pet
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add a new pet</DialogTitle>
                  <DialogDescription>Create a profile to track your pet's health.</DialogDescription>
                </DialogHeader>
                <form
                  className="space-y-4"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const form = new FormData(e.currentTarget);
                    try {
                      await createPet.mutateAsync({
                        name: form.get("name") as string,
                        species: form.get("species") as string,
                        breed: (form.get("breed") as string) || null,
                        age: (form.get("age") as string) || null,
                      });
                      setOpen(false);
                      toast.success("Pet added successfully!");
                    } catch (err) {
                      toast.error(err instanceof Error ? err.message : "Failed to add pet");
                    }
                  }}
                >
                  <div className="flex justify-center">
                    <button
                      type="button"
                      className="grid h-20 w-20 place-items-center rounded-2xl border border-dashed text-muted-foreground hover:bg-accent"
                    >
                      <Upload className="h-6 w-6" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input id="name" name="name" placeholder="Bingo" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="species">Species</Label>
                      <Input id="species" name="species" placeholder="Dog" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="breed">Breed</Label>
                      <Input id="breed" name="breed" placeholder="Golden Retriever" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="age">Age</Label>
                      <Input id="age" name="age" placeholder="3 years" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" variant="hero" className="w-full" disabled={createPet.isPending}>
                      Save Pet
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          }
        />

        {pets.length === 0 ? (
          <EmptyState title="No pets yet" description="Add your first pet to start tracking their health." />
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {pets.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPetId(p.id)}
                className={`hover-lift overflow-hidden rounded-2xl border bg-card text-left shadow-sm transition-all ${
                  activePetId === p.id ? "ring-2 ring-primary" : ""
                }`}
              >
                <div className="flex items-center gap-3 p-5">
                  <Avatar className="h-14 w-14">
                    <AvatarImage src={p.photo} alt={p.name} />
                    <AvatarFallback>{p.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-bold">{p.name}</p>
                    <p className="text-xs text-muted-foreground">{p.breed}</p>
                  </div>
                  <StatusBadge tone={p.healthStatus}>{p.healthLabel}</StatusBadge>
                </div>
                <dl className="grid grid-cols-3 gap-2 border-t px-5 py-4 text-center text-xs">
                  <div>
                    <dt className="text-muted-foreground">Age</dt>
                    <dd className="mt-0.5 font-semibold">{p.age}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Weight</dt>
                    <dd className="mt-0.5 font-semibold">{p.weight}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Gender</dt>
                    <dd className="mt-0.5 font-semibold">{p.gender}</dd>
                  </div>
                </dl>
              </button>
            ))}
          </div>
        )}

        {selectedPet && (
          <div className="grid gap-6 lg:grid-cols-2">
            <SectionCard title={`Vaccination History — ${selectedPet.name}`}>
              {vaccinations.length === 0 ? (
                <p className="text-sm text-muted-foreground">No vaccination records yet.</p>
              ) : (
                <ol className="relative space-y-5 border-l pl-6">
                  {vaccinations.map((t) => (
                    <li key={t.id} className="relative">
                      <span className="absolute -left-[31px] grid h-5 w-5 place-items-center rounded-full bg-success text-success-foreground">
                        <Syringe className="h-3 w-3" />
                      </span>
                      <p className="text-sm font-semibold">{t.diagnosis}</p>
                      <p className="text-xs text-muted-foreground">{t.date}</p>
                    </li>
                  ))}
                </ol>
              )}
            </SectionCard>

            <SectionCard title={`Medical History — ${selectedPet.name}`}>
              {medicalHistory.length === 0 ? (
                <p className="text-sm text-muted-foreground">No medical records yet.</p>
              ) : (
                <ul className="space-y-3">
                  {medicalHistory.map((m) => (
                    <li key={m.id} className="flex items-center gap-3 rounded-xl border p-3">
                      <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/10 text-primary">
                        <Stethoscope className="h-4 w-4" />
                      </span>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{m.type} — {m.diagnosis}</p>
                        <p className="text-xs text-muted-foreground">{m.date} · {m.vet}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </SectionCard>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
