import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { MapPin, Search, Star } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/status-badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LoadingState } from "@/components/ui/loading-state";
import { useVets } from "@/hooks/use-vets";

export const Route = createFileRoute("/find-vet")({
  head: () => ({
    meta: [
      { title: "Find a Veterinarian — VetCare Ghana" },
      { name: "description", content: "Browse verified veterinarians across Ghana by specialization, location, and rating." },
    ],
  }),
  component: FindVetPage,
});

function FindVetPage() {
  const [query, setQuery] = useState("");
  const { data: vets = [], isLoading } = useVets();

  const filtered = vets.filter(
    (v) =>
      v.name.toLowerCase().includes(query.toLowerCase()) ||
      v.specialization.toLowerCase().includes(query.toLowerCase()) ||
      v.location.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-12">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold sm:text-4xl">Find a Veterinarian</h1>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Verified, trusted veterinarians ready to care for your pet.
          </p>
        </div>

        <div className="mx-auto mt-8 max-w-md">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, specialty, or city..."
              className="pl-9"
            />
          </div>
        </div>

        {isLoading ? (
          <LoadingState />
        ) : filtered.length === 0 ? (
          <p className="mt-10 text-center text-muted-foreground">No veterinarians found.</p>
        ) : (
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((v) => (
              <div key={v.id} className="hover-lift rounded-2xl border bg-card p-6 text-center shadow-sm">
                <Avatar className="mx-auto h-20 w-20">
                  <AvatarImage src={v.photo} alt={v.name} />
                  <AvatarFallback>{v.name[0]}</AvatarFallback>
                </Avatar>
                <h2 className="mt-4 font-bold">{v.name}</h2>
                <p className="text-sm text-primary">{v.specialization}</p>
                <div className="mt-2 flex items-center justify-center gap-1 text-sm">
                  <Star className="h-4 w-4 fill-warning text-warning" />
                  <span className="font-semibold">{v.rating}</span>
                  <span className="text-muted-foreground">({v.reviews})</span>
                </div>
                <div className="mt-2 flex items-center justify-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3.5 w-3.5" /> {v.location} · {v.experience}
                </div>
                <div className="mt-3">
                  <StatusBadge tone={v.available ? "success" : "muted"}>
                    {v.available ? "Available today" : "Fully booked"}
                  </StatusBadge>
                </div>
                <Button asChild variant="hero" className="mt-5 w-full">
                  <Link to="/dashboard/appointments">Book Appointment</Link>
                </Button>
              </div>
            ))}
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
