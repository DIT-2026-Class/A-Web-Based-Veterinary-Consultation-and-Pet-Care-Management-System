import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays, DollarSign, Stethoscope, Users } from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { StatCard } from "@/components/dashboard/StatCard";
import { SectionCard } from "@/components/dashboard/Primitives";
import { StatusBadge } from "@/components/ui/status-badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { LoadingState } from "@/components/ui/loading-state";
import { useAuth } from "@/lib/auth";
import { useVetAppointments } from "@/hooks/use-appointments";
import { useCurrentVet } from "@/hooks/use-vets";
import { groupAppointmentsByWeekday } from "@/lib/api/appointments";
import { isToday, parseISO } from "date-fns";

export const Route = createFileRoute("/vet/")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>) => ({
    view: typeof search.view === "string" ? search.view : undefined,
  }),
  head: () => ({ meta: [{ title: "Vet Dashboard — VetCare Ghana" }] }),
  component: VetDashboard,
});

function VetDashboard() {
  return (
    <RequireAuth role="vet">
      <VetDashboardContent />
    </RequireAuth>
  );
}

function VetDashboardContent() {
  const { profile } = useAuth();
  const { data: vet } = useCurrentVet();
  const { data: appointments = [], isLoading } = useVetAppointments();

  if (isLoading) {
    return (
      <DashboardLayout role="vet">
        <LoadingState />
      </DashboardLayout>
    );
  }

  const todayAppts = appointments.filter((a) => a.scheduledAt && isToday(parseISO(a.scheduledAt)));
  const upcoming = appointments.filter((a) => a.status === "upcoming");
  const queue = upcoming.slice(0, 3);
  const chartData = groupAppointmentsByWeekday(appointments);
  const monthlyConsults = appointments.filter((a) => a.status === "completed").length;
  const revenue = monthlyConsults * (vet?.consultationFee ?? 0);

  return (
    <DashboardLayout role="vet">
      <div className="space-y-6">
        <h1 className="text-2xl font-extrabold sm:text-3xl">
          Good morning, {profile?.full_name ?? vet?.name ?? "Doctor"}
        </h1>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Today's Appointments" value={todayAppts.length} icon={CalendarDays} tone="primary" index={0} />
          <StatCard label="Patients in Queue" value={queue.length} icon={Users} tone="info" index={1} />
          <StatCard label="Consultations (mo)" value={monthlyConsults} icon={Stethoscope} tone="success" index={2} />
          <StatCard label="Revenue (mo)" value={`GHS ${(revenue / 1000).toFixed(1)}k`} icon={DollarSign} tone="warning" index={3} />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <SectionCard title="Consultations this week" className="lg:col-span-2">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--color-primary)" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="var(--color-primary)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 12,
                    }}
                  />
                  <Area type="monotone" dataKey="consults" stroke="var(--color-primary)" strokeWidth={2} fill="url(#g)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </SectionCard>

          <SectionCard title="Patient Queue">
            <div className="space-y-3">
              {queue.length === 0 ? (
                <p className="text-sm text-muted-foreground">No patients in queue.</p>
              ) : (
                queue.map((a) => (
                  <div key={a.id} className="flex items-center gap-3 rounded-xl border p-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={a.petPhoto} alt={a.petName} />
                      <AvatarFallback>{a.petName[0]}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{a.petName}</p>
                      <p className="truncate text-xs text-muted-foreground">{a.type}</p>
                    </div>
                    <StatusBadge tone="info">{a.time}</StatusBadge>
                  </div>
                ))
              )}
            </div>
          </SectionCard>
        </div>

        <SectionCard title="Upcoming Consultations">
          <div className="space-y-3">
            {upcoming.length === 0 ? (
              <p className="text-sm text-muted-foreground">No upcoming consultations.</p>
            ) : (
              upcoming.map((a) => (
                <div key={a.id} className="flex items-center gap-3 rounded-xl border p-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={a.petPhoto} alt={a.petName} />
                    <AvatarFallback>{a.petName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{a.type}</p>
                    <p className="truncate text-xs text-muted-foreground">{a.petName} · {a.date} {a.time}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </SectionCard>
      </div>
    </DashboardLayout>
  );
}
