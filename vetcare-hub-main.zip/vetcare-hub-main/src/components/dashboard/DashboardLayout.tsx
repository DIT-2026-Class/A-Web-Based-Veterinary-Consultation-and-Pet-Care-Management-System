import { useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Bell,
  CalendarDays,
  FileHeart,
  LayoutDashboard,
  LogOut,
  Menu,
  PawPrint,
  Search,
  Settings,
  Stethoscope,
  Users,
  Video,
  X,
  BookOpen,
  BarChart3,
  ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { homeForRole, useAuth } from "@/lib/auth";
import { photoOrDefault } from "@/lib/format";
import { useNotifications } from "@/hooks/use-notifications";

export type DashRole = "owner" | "vet" | "admin";

type NavItem = { label: string; to: string; icon: typeof LayoutDashboard; view?: string };

const navConfig: Record<DashRole, NavItem[]> = {
  owner: [
    { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard },
    { label: "My Pets", to: "/dashboard/pets", icon: PawPrint },
    { label: "Appointments", to: "/dashboard/appointments", icon: CalendarDays },
    { label: "Consultation", to: "/dashboard/consultation", icon: Video },
    { label: "Health Records", to: "/dashboard/records", icon: FileHeart },
    { label: "Health Center", to: "/health-center", icon: BookOpen },
  ],
  vet: [
    { label: "Dashboard", to: "/vet", icon: LayoutDashboard },
    { label: "Patient Queue", to: "/vet", icon: Users, view: "queue" },
    { label: "Consultations", to: "/dashboard/consultation", icon: Video },
    { label: "My Profile", to: "/vet/profile", icon: Stethoscope },
  ],
  admin: [
    { label: "Overview", to: "/admin", icon: LayoutDashboard },
    { label: "Analytics", to: "/admin", icon: BarChart3, view: "analytics" },
    { label: "Users", to: "/admin", icon: Users, view: "users" },
    { label: "Verification", to: "/admin", icon: ShieldCheck, view: "verification" },
  ],
};

const roleLabels: Record<DashRole, string> = {
  owner: "Pet Owner",
  vet: "Veterinarian",
  admin: "Administrator",
};

const settingsPath: Record<DashRole, string> = {
  owner: "/dashboard",
  vet: "/vet/profile",
  admin: "/admin",
};

export function DashboardLayout({
  role,
  children,
}: {
  role: DashRole;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const search = useRouterState({ select: (s) => s.location.search as Record<string, unknown> });
  const currentView = typeof search?.view === "string" ? search.view : "";
  const { profile, signOut } = useAuth();
  const { data: notifications } = useNotifications();
  const items = navConfig[role];

  const name = profile?.full_name || "User";
  const avatar = photoOrDefault(profile?.avatar_url);
  const unreadCount = notifications?.filter((n) => !n.read).length ?? 0;

  const isActive = (item: NavItem) => {
    if (pathname !== item.to) return false;
    const siblings = items.filter((i) => i.to === item.to);
    if (siblings.length === 1) return true;
    // Multiple nav items share this path — disambiguate by the `view` param.
    if (currentView) return (item.view ?? "") === currentView;
    // No view selected → only the first (default) sibling is active.
    return siblings[0] === item;
  };

  const handleSignOut = async () => {
    await signOut();
    toast.success("Logged out");
    navigate({ to: "/login" });
  };

  const SidebarBody = (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center px-5">
        <Logo />
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4" aria-label="Dashboard">
        {items.map((item) => (
          <Link
            key={item.label}
            to={item.to}
            search={item.view ? { view: item.view } : {}}
            onClick={() => setOpen(false)}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
              isActive(item)
                ? "bg-gradient-primary text-primary-foreground shadow-glow"
                : "text-muted-foreground hover:bg-accent hover:text-foreground",
            )}
          >
            <item.icon className="h-[18px] w-[18px]" />
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="p-3">
        <Link
          to={settingsPath[role]}
          className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <Settings className="h-[18px] w-[18px]" /> Settings
        </Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r bg-sidebar lg:block">
        {SidebarBody}
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-foreground/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-64 animate-slide-in-right bg-sidebar shadow-soft">
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-3"
              onClick={() => setOpen(false)}
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </Button>
            {SidebarBody}
          </div>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur-md sm:px-6">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </Button>

          <div className="relative hidden max-w-sm flex-1 sm:block">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search pets, vets, records..." className="pl-9" />
          </div>

          <div className="ml-auto flex items-center gap-1">
            <ThemeToggle />
            <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-destructive" />
              )}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-full p-1 pr-2 transition-colors hover:bg-accent">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={avatar} alt={name} />
                    <AvatarFallback>{name[0]}</AvatarFallback>
                  </Avatar>
                  <span className="hidden text-left sm:block">
                    <span className="block text-sm font-semibold leading-tight">{name}</span>
                    <span className="block text-xs text-muted-foreground">{roleLabels[role]}</span>
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuLabel>{name}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate({ to: homeForRole(role) })}>
                  <LayoutDashboard className="h-4 w-4" /> Dashboard
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => toast("Settings coming soon")}>
                  <Settings className="h-4 w-4" /> Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={handleSignOut}
                >
                  <LogOut className="h-4 w-4" /> Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
