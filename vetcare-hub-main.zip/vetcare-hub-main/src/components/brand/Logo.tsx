import { Link } from "@tanstack/react-router";
import { PawPrint } from "lucide-react";
import { cn } from "@/lib/utils";

export function Logo({
  className,
  to = "/",
  showText = true,
}: {
  className?: string;
  to?: string;
  showText?: boolean;
}) {
  return (
    <Link to={to} className={cn("flex items-center gap-2.5 group", className)} aria-label="VetCare Ghana home">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-primary text-primary-foreground shadow-glow transition-transform group-hover:scale-105">
        <PawPrint className="h-5 w-5" />
      </span>
      {showText && (
        <span className="font-display text-lg font-extrabold tracking-tight">
          Vet<span className="text-primary">Care</span>
        </span>
      )}
    </Link>
  );
}
