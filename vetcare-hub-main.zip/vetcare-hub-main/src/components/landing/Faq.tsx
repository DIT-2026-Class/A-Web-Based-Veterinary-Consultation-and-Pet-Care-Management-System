import { Link } from "@tanstack/react-router";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

const faqs = [
  {
    q: "How do online consultations work?",
    a: "After booking, you'll join a secure video call with a licensed veterinarian at your scheduled time. You can chat, share photos, and receive prescriptions digitally.",
  },
  {
    q: "Are the veterinarians verified?",
    a: "Yes. Every veterinarian on VetCare Ghana is verified for licensing and qualifications before they can accept appointments.",
  },
  {
    q: "Can I manage more than one pet?",
    a: "Absolutely. You can add unlimited pets to your account, each with their own profile, vaccination history, and medical records.",
  },
  {
    q: "How do I pay for appointments?",
    a: "We support mobile money and card payments. You'll see transparent pricing before you confirm any booking.",
  },
  {
    q: "Is my pet's data secure?",
    a: "Your data is encrypted and only accessible to you and the veterinarians you choose to consult with.",
  },
];

export function Faq() {
  return (
    <section id="faq" className="scroll-mt-24 bg-card py-20">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 md:grid-cols-[0.8fr_1.2fr]">
        <div>
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">FAQ</span>
          <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">Frequently asked questions</h2>
          <p className="mt-4 text-muted-foreground">
            Can't find what you're looking for? Our support team is here to help.
          </p>
          <Button asChild variant="outline" className="mt-6">
            <Link to="/register">Contact Support</Link>
          </Button>
        </div>

        <Accordion type="single" collapsible className="w-full">
          {faqs.map((f, i) => (
            <AccordionItem key={i} value={`item-${i}`} className="border-b">
              <AccordionTrigger className="text-left text-base font-semibold hover:no-underline">
                {f.q}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
