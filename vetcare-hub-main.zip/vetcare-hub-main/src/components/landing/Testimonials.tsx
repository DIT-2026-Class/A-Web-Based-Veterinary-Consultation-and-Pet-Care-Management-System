import { motion } from "framer-motion";
import { Quote, Star } from "lucide-react";

const testimonials = [
  {
    name: "Akosua Darko",
    role: "Dog owner, Accra",
    quote:
      "I booked a video consultation at 9pm when Bingo was unwell. The vet was kind, fast, and the prescription came through instantly. Lifesaver!",
    photo:
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=120&q=80",
  },
  {
    name: "Yaw Boateng",
    role: "Cat owner, Kumasi",
    quote:
      "Having all of Mittens' vaccination records in one app means I never miss a booster. The reminders are brilliant.",
    photo:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80",
  },
  {
    name: "Dr. Nana Adjei",
    role: "Veterinarian, Takoradi",
    quote:
      "VetCare lets me manage my schedule, consult remotely, and keep clean digital records. It's transformed my small practice.",
    photo:
      "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=120&q=80",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="mx-auto max-w-6xl scroll-mt-24 px-4 py-20">
      <div className="mx-auto max-w-2xl text-center">
        <span className="text-sm font-semibold uppercase tracking-wider text-primary">
          Testimonials
        </span>
        <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">Loved by pets and their people</h2>
      </div>

      <div className="mt-14 grid gap-6 md:grid-cols-3">
        {testimonials.map((t, i) => (
          <motion.figure
            key={t.name}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
            className="hover-lift rounded-3xl border bg-card p-7 shadow-sm"
          >
            <Quote className="h-8 w-8 text-primary/30" />
            <blockquote className="mt-4 text-sm leading-relaxed text-foreground">
              "{t.quote}"
            </blockquote>
            <div className="mt-6 flex items-center gap-3">
              <img src={t.photo} alt={t.name} className="h-11 w-11 rounded-full object-cover" loading="lazy" />
              <figcaption>
                <p className="text-sm font-semibold">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.role}</p>
              </figcaption>
              <div className="ml-auto flex gap-0.5 text-warning">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star key={s} className="h-3.5 w-3.5 fill-current" />
                ))}
              </div>
            </div>
          </motion.figure>
        ))}
      </div>
    </section>
  );
}
