import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { CalendarPlus, Search, ShieldCheck, Star, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero-vet.jpg";

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-hero">
      <div className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -left-32 h-96 w-96 rounded-full bg-info/20 blur-3xl" />

      <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 md:grid-cols-2 md:py-24">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="inline-flex items-center gap-2 rounded-full border bg-background/70 px-3 py-1 text-xs font-semibold text-primary backdrop-blur">
            <ShieldCheck className="h-3.5 w-3.5" /> Ghana's trusted pet healthcare platform
          </span>

          <h1 className="mt-5 text-4xl font-extrabold leading-[1.05] sm:text-5xl lg:text-6xl">
            Veterinary Care <span className="text-gradient">Anywhere</span>, Anytime
          </h1>

          <p className="mt-5 max-w-md text-base text-muted-foreground sm:text-lg">
            Book appointments, consult licensed veterinarians online, and manage your pet's complete
            health records — all from one beautiful, simple platform.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="hero" size="lg">
              <Link to="/register">
                <CalendarPlus className="h-5 w-5" /> Book Appointment
              </Link>
            </Button>
            <Button asChild variant="glass" size="lg">
              <Link to="/find-vet">
                <Search className="h-5 w-5" /> Find a Veterinarian
              </Link>
            </Button>
          </div>

          <div className="mt-8 flex items-center gap-6">
            <div className="flex -space-x-3">
              {[
                "https://images.unsplash.com/photo-1633722715463-d30f4f325e24?auto=format&fit=crop&w=80&q=80",
                "https://images.unsplash.com/photo-1574158622682-e40e69881006?auto=format&fit=crop&w=80&q=80",
                "https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=80&q=80",
              ].map((src) => (
                <img
                  key={src}
                  src={src}
                  alt=""
                  className="h-10 w-10 rounded-full border-2 border-background object-cover"
                  loading="lazy"
                />
              ))}
            </div>
            <div>
              <div className="flex items-center gap-1 text-warning">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground">Loved by 10,000+ pet owners</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="relative"
        >
          <div className="overflow-hidden rounded-3xl border shadow-soft">
            <img
              src={heroImg}
              alt="A veterinarian gently caring for a happy golden retriever"
              width={1280}
              height={1024}
              className="h-full w-full object-cover"
            />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="glass absolute -bottom-5 -left-5 hidden items-center gap-3 rounded-2xl p-4 shadow-soft sm:flex"
          >
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-info/15 text-info">
              <Video className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold">Live Consultation</p>
              <p className="text-xs text-muted-foreground">Dr. Ama is online now</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.65 }}
            className="glass absolute -right-4 top-8 hidden rounded-2xl p-4 shadow-soft sm:block"
          >
            <p className="text-2xl font-extrabold text-primary">98%</p>
            <p className="text-xs text-muted-foreground">Recovery rate</p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
