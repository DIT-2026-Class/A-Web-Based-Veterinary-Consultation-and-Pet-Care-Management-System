import { motion } from "framer-motion";
import {
  CalendarCheck,
  FileHeart,
  PawPrint,
  Pill,
  Stethoscope,
  Video,
} from "lucide-react";

const features = [
  {
    icon: Video,
    title: "Virtual Consultations",
    desc: "Connect with licensed vets over secure video calls from the comfort of home.",
    tone: "text-info bg-info/15",
  },
  {
    icon: CalendarCheck,
    title: "Easy Appointments",
    desc: "Browse availability and book in-person or online visits in just a few taps.",
    tone: "text-primary bg-primary/15",
  },
  {
    icon: FileHeart,
    title: "Digital Health Records",
    desc: "Vaccinations, diagnoses, and prescriptions stored safely in one place.",
    tone: "text-warning bg-warning/15",
  },
  {
    icon: Pill,
    title: "E-Prescriptions",
    desc: "Receive and track prescriptions digitally with dosage reminders.",
    tone: "text-success bg-success/15",
  },
  {
    icon: PawPrint,
    title: "Multi-Pet Profiles",
    desc: "Manage every pet in your family with rich, organised health profiles.",
    tone: "text-info bg-info/15",
  },
  {
    icon: Stethoscope,
    title: "Trusted Veterinarians",
    desc: "Every vet is verified, rated, and reviewed by the VetCare community.",
    tone: "text-primary bg-primary/15",
  },
];

export function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl scroll-mt-24 px-4 py-20">
      <div className="mx-auto max-w-2xl text-center">
        <span className="text-sm font-semibold uppercase tracking-wider text-primary">Features</span>
        <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">
          Everything your pet's health needs
        </h2>
        <p className="mt-4 text-muted-foreground">
          A complete toolkit for modern pet care — designed to be simple for everyone.
        </p>
      </div>

      <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.4, delay: i * 0.05 }}
            className="hover-lift group rounded-3xl border bg-card p-6 shadow-sm"
          >
            <span className={`grid h-12 w-12 place-items-center rounded-2xl ${f.tone}`}>
              <f.icon className="h-6 w-6" />
            </span>
            <h3 className="mt-5 text-lg font-bold">{f.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
