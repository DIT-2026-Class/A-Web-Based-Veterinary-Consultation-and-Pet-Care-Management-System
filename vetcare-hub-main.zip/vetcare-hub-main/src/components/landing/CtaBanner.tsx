import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export function CtaBanner() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-[2rem] bg-gradient-primary p-10 text-center shadow-glow sm:p-16"
      >
        <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-background/10 blur-2xl" />
        <h2 className="text-3xl font-extrabold text-primary-foreground sm:text-4xl">
          Give your pet the care they deserve
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-primary-foreground/90">
          Join thousands of Ghanaian pet owners managing their pets' health the smart way.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg" className="bg-background text-foreground hover:bg-background/90">
            <Link to="/register">Get Started Free</Link>
          </Button>
          <Button asChild variant="glass" size="lg">
            <Link to="/find-vet">Browse Veterinarians</Link>
          </Button>
        </div>
      </motion.div>
    </section>
  );
}
