import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { ThemeToggle } from "@/components/theme/ThemeToggle";

const highlights = [
  "Consult licensed vets by video, anytime",
  "Manage every pet's health in one place",
  "Digital records, prescriptions & reminders",
];

export function AuthShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Brand panel */}
      <div className="relative hidden overflow-hidden bg-gradient-primary p-12 lg:flex lg:flex-col lg:justify-between">
        <div className="pointer-events-none absolute -right-24 top-10 h-80 w-80 rounded-full bg-background/10 blur-3xl" />
        <Logo className="[&_span:last-child]:text-primary-foreground" />
        <div className="relative z-10 max-w-md">
          <h2 className="text-4xl font-extrabold leading-tight text-primary-foreground">
            Veterinary care anywhere, anytime.
          </h2>
          <ul className="mt-8 space-y-4">
            {highlights.map((h) => (
              <li key={h} className="flex items-center gap-3 text-primary-foreground/95">
                <CheckCircle2 className="h-5 w-5 shrink-0" />
                <span>{h}</span>
              </li>
            ))}
          </ul>
        </div>
        <p className="relative z-10 text-sm text-primary-foreground/80">
          Trusted by 10,000+ pet owners across Ghana.
        </p>
      </div>

      {/* Form panel */}
      <div className="flex flex-col bg-background">
        <header className="flex items-center justify-between p-6">
          <Logo className="lg:hidden" />
          <span className="hidden lg:block" />
          <ThemeToggle />
        </header>

        <main className="flex flex-1 items-center justify-center px-6 pb-12">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="w-full max-w-md"
          >
            <h1 className="text-2xl font-extrabold">{title}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>
            <div className="mt-8">{children}</div>
          </motion.div>
        </main>

        <footer className="p-6 text-center text-sm text-muted-foreground">
          <Link to="/" className="hover:text-foreground">
            ← Back to home
          </Link>
        </footer>
      </div>
    </div>
  );
}
