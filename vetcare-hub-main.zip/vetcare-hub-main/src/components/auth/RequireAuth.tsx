import { useEffect, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { homeForRole, useAuth, type AppRole } from "@/lib/auth";

function roleAllowed(required: AppRole | AppRole[], actual: AppRole | null) {
  if (!actual) return false;
  return Array.isArray(required) ? required.includes(actual) : actual === required;
}

export function RequireAuth({
  role,
  children,
}: {
  role?: AppRole | AppRole[];
  children: ReactNode;
}) {
  const { user, role: userRole, loading, initialized } = useAuth();
  const navigate = useNavigate();

  const waiting = !initialized || loading || (Boolean(user) && role && userRole === null);

  useEffect(() => {
    if (waiting) return;
    if (!user) {
      navigate({ to: "/login", replace: true });
      return;
    }
    if (role && userRole && !roleAllowed(role, userRole)) {
      navigate({ to: homeForRole(userRole), replace: true });
    }
  }, [waiting, user, userRole, role, navigate]);

  if (waiting) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) return null;
  if (role && userRole && !roleAllowed(role, userRole)) return null;

  return <>{children}</>;
}
