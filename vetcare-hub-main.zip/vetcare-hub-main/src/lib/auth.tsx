import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { fetchMe, login as apiLogin, logout as apiLogout, mapBackendRole, normalizeProfile, register as apiRegister } from "@/lib/api/auth";

export type AppRole = "owner" | "vet" | "admin";

export interface Profile {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  location: string | null;
  avatar_url: string | null;
  bio: string | null;
}

interface AuthContextValue {
  user: { id: string; email: string | null } | null;
  profile: Profile | null;
  role: AppRole | null;
  loading: boolean;
  initialized: boolean;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (fullName: string, email: string, password: string, role: "owner" | "vet" | "admin") => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function homeForRole(role: AppRole | null): string {
  if (role === "vet") return "/vet";
  if (role === "admin") return "/admin";
  return "/dashboard";
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<{ id: string; email: string | null } | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);

  const loadUser = async () => {
    setLoading(true);
    try {
      const response = await fetchMe();
      const roleValue = mapBackendRole(response.data.role);
      setUser({ id: response.data.id, email: response.data.email });
      setProfile(normalizeProfile(response.data));
      setRole(roleValue);
    } catch (error) {
      setUser(null);
      setProfile(null);
      setRole(null);
    } finally {
      setLoading(false);
      setInitialized(true);
    }
  };

  useEffect(() => {
    loadUser();
  }, []);

  const refresh = async () => {
    await loadUser();
  };

  const signOut = async () => {
    await apiLogout();
    setUser(null);
    setProfile(null);
    setRole(null);
  };

  const signIn = async (email: string, password: string) => {
    const response = await apiLogin(email, password);
    const roleValue = mapBackendRole(response.data.role);
    setUser({ id: response.data.id, email: response.data.email });
    setProfile(normalizeProfile(response.data));
    setRole(roleValue);
    setInitialized(true);
  };

  const signUp = async (fullName: string, email: string, password: string, roleValue: "owner" | "vet" | "admin") => {
    const response = await apiRegister(fullName, email, password, roleValue);
    const mappedRole = mapBackendRole(response.data.role);
    setUser({ id: response.data.id, email: response.data.email });
    setProfile(normalizeProfile(response.data));
    setRole(mappedRole);
    setInitialized(true);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        role,
        loading,
        initialized,
        refresh,
        signOut,
        signIn,
        signUp,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
