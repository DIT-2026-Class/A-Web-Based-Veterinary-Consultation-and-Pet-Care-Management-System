import { apiGet } from "./client";
import { asStatusTone, type StatusTone } from "@/lib/status";
import { formatDate } from "@/lib/format";

export interface MedicalRecordView {
  id: string;
  petName: string;
  petId: string | null;
  date: string;
  type: string;
  diagnosis: string;
  vet: string;
  status: StatusTone;
  recordDate: string;
}

type RecordRow = any;

function toRecordView(row: RecordRow): MedicalRecordView {
  return {
    id: row.id,
    petName: row.pet_name ?? row.pet_id ?? "Unknown pet",
    petId: row.pet_id ?? null,
    date: row.visit_date ? formatDate(row.visit_date) : "",
    type: row.type ?? "",
    diagnosis: row.diagnosis ?? "—",
    vet: row.vet_name ?? "—",
    status: asStatusTone((row.status as string) ?? undefined),
    recordDate: row.visit_date ?? "",
  };
}

export async function fetchMedicalRecords(ownerId: string): Promise<MedicalRecordView[]> {
  const data = await apiGet<any[]>(`/api/medical-records?owner_id=${encodeURIComponent(ownerId)}`);
  return (data ?? []).map((row) => toRecordView(row));
}

export async function fetchPetMedicalRecords(petId: string): Promise<MedicalRecordView[]> {
  const data = await apiGet<any[]>(`/api/medical-records?pet_id=${encodeURIComponent(petId)}`);
  return (data ?? []).map((row) => toRecordView(row));
}

export async function fetchVaccinationRecords(petId: string): Promise<MedicalRecordView[]> {
  const data = await apiGet<any[]>(`/api/medical-records?pet_id=${encodeURIComponent(petId)}&type=Vaccination`);
  return (data ?? []).map((row) => toRecordView(row));
}
