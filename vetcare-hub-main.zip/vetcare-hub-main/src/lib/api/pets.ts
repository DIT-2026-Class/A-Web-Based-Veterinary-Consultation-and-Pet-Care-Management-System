import { apiGet, apiPost } from "./client";
import type { PetInsert } from "./db-types";
import { asStatusTone, type StatusTone } from "@/lib/status";
import { photoOrDefault } from "@/lib/format";

export interface PetView {
  id: string;
  name: string;
  species: string;
  breed: string;
  age: string;
  weight: string;
  gender: string;
  photo: string;
  healthStatus: StatusTone;
  healthLabel: string;
}

function toPetView(row: any): PetView {
  return {
    id: row._id?.toString(),
    name: row.name,
    species: row.species,
    breed: row.breed ?? "—",
    age: row.age ? String(row.age) : "—",
    weight: row.weight ? String(row.weight) : "—",
    gender: row.gender ?? "—",
    photo: photoOrDefault(row.photo ?? null),
    healthStatus: asStatusTone(row.vaccinationStatus),
    healthLabel: row.vaccinationStatus ?? "Not Updated",
  };
}

export async function fetchPets(ownerId: string): Promise<PetView[]> {
  const res = await apiGet<any>(`/api/pets?owner_id=${encodeURIComponent(ownerId)}`);
  const data = Array.isArray(res) ? res : (res.data ?? []);
  return data.map(toPetView);
}

export async function createPet(ownerId: string, input: PetInsert): Promise<PetView> {
  const data = await apiPost<any>("/api/pets", { ...input, owner_id: ownerId });
  return toPetView(data.data ?? data);
}