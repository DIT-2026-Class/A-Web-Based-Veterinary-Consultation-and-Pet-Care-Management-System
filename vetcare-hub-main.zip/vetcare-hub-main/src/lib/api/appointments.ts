import { apiGet, apiPost, apiPatch } from "./client";
import { formatDate, formatTime, photoOrDefault } from "@/lib/format";

export type AppointmentStatus = "upcoming" | "completed" | "cancelled" | "in-progress";

export interface AppointmentView {
  id: string;
  petName: string;
  petPhoto: string;
  vet: string;
  type: string;
  date: string;
  time: string;
  status: AppointmentStatus;
  scheduledAt: string | null;
  petId: string | null;
  vetId: string | null;
  mode?: string;
  notes: string | null;
}

type AppointmentRow = any;

function toAppointmentView(row: AppointmentRow): AppointmentView {
  return {
    id: row.id,
    petName: (row.pet_name as string) ?? row.pet_id ?? "Unknown pet",
    petPhoto: photoOrDefault((row.pet_photo as string) ?? null),
    vet: (row.vet_name as string) ?? "Unassigned",
    type: row.type ?? "Consultation",
    date: row.scheduled_at ? formatDate(row.scheduled_at) : "",
    time: row.scheduled_at ? formatTime(row.scheduled_at) : "",
    status: (row.status as AppointmentStatus) ?? "upcoming",
    scheduledAt: row.scheduled_at ?? null,
    petId: row.pet_id ?? null,
    vetId: row.vet_id ?? null,
    mode: row.mode,
    notes: row.notes ?? null,
  };
}

export async function fetchOwnerAppointments(ownerId: string): Promise<AppointmentView[]> {
  const data = await apiGet<any[]>(`/api/appointments?owner_id=${encodeURIComponent(ownerId)}`);
  return (data ?? []).map((row) => toAppointmentView(row));
}

export async function fetchVetAppointments(vetId: string): Promise<AppointmentView[]> {
  const data = await apiGet<any[]>(`/api/appointments`);
  const rows = (data ?? []).filter((r) => String(r.vet_id) === String(vetId));
  return rows.map((row) => toAppointmentView(row));
}

export async function createAppointment(
  ownerId: string,
  input: {
    petId: string;
    vetId: string;
    type: string;
    scheduledAt: string;
    mode?: string;
  },
): Promise<{ id: string }> {
  const payload = {
    owner_id: ownerId,
    pet_id: input.petId,
    vet_id: input.vetId,
    type: input.type,
    scheduled_at: input.scheduledAt,
    mode: input.mode ?? "in-person",
    status: "upcoming",
  };

  const data = await apiPost<{ id: string }>("/api/appointments", payload);
  return data;
}

export async function updateAppointmentStatus(id: string, status: AppointmentStatus): Promise<void> {
  await apiPatch(`/api/appointments/${encodeURIComponent(id)}`, { status });
}

export function groupAppointmentsByWeekday(appointments: AppointmentView[]) {
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const counts = days.map((day) => ({ day, consults: 0 }));

  for (const appt of appointments) {
    if (!appt.scheduledAt) continue;
    const d = new Date(appt.scheduledAt);
    const dayIndex = d.getDay();
    counts[dayIndex].consults += 1;
  }

  return [...counts.slice(1), counts[0]];
}
