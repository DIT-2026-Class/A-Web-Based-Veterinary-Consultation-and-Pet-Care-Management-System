import { apiGet, apiPatch, apiPost } from "./client";
import type { VetRow, VetUpdate } from "./db-types";
import { photoOrDefault } from "@/lib/format";

export interface VetView {
  id: string;
  name: string;
  specialization: string;
  experience: string;
  rating: number;
  reviews: number;
  location: string;
  photo: string;
  available: boolean;
  bio: string | null;
  consultationFee: number;
  userId: string | null;
}

function toVetView(row: VetRow): VetView {
  return {
    id: row.id,
    name: row.name,
    specialization: row.specialization,
    experience: `${row.experience_years} years`,
    rating: Number(row.rating),
    reviews: row.reviews_count,
    location: row.location ?? "Ghana",
    photo: photoOrDefault(row.photo),
    available: row.available,
    bio: row.bio,
    consultationFee: row.consultation_fee,
    userId: row.user_id,
  };
}

export async function fetchVets(): Promise<VetView[]> {
  const data = await apiGet<any[]>("/api/vets");

  return (data ?? []).map(toVetView);
}

export async function fetchVetByUserId(userId: string): Promise<VetView | null> {
  const data = await apiGet<any>(`/api/vets/by-user?user_id=${encodeURIComponent(userId)}`);
  return data ? toVetView(data) : null;
}

export async function updateVet(id: string, updates: VetUpdate): Promise<VetView> {
  const data = await apiPatch<any>(`/api/vets/${id}`, updates);
  return toVetView(data);
}

export async function toggleVetAvailability(id: string, available: boolean): Promise<void> {
  await apiPost(`/api/vets/${encodeURIComponent(id)}/availability`, { available });
}
