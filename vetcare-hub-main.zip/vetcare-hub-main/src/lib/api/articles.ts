import { apiGet } from "./client";

export interface ArticleView {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  readTime: string;
  image: string;
  content: string | null;
}

const DEFAULT_IMAGE =
  "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=600&q=80";

function toArticleView(row: any): ArticleView {
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    excerpt: row.excerpt ?? "",
    readTime: row.read_time ?? "5 min read",
    image: row.image ?? DEFAULT_IMAGE,
    content: row.content,
  };
}

export async function fetchArticles(): Promise<ArticleView[]> {
  const data = await apiGet<any[]>("/api/articles");
  return (data ?? []).map(toArticleView);
}

export function getArticleCategories(articles: ArticleView[]): string[] {
  const cats = new Set(articles.map((a) => a.category));
  return ["All", ...Array.from(cats).sort()];
}
