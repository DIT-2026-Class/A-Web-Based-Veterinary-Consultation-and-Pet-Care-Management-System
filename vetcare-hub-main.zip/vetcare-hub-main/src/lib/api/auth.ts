import { apiGet, apiPost, setApiToken } from "./client";
import type { AppRole } from "../auth";

export interface AuthUser {
  id: string;
  fullName: string;
  email: string | null;
  role: AppRole;
}

export interface AuthResponse {
  success: boolean;
  token: string;
  data: {
    id: string;
    fullName: string;
    email: string;
    role: string;
  };
}

export function mapBackendRole(role: string): AppRole {
  if (role === "veterinarian") return "vet";
  if (role === "admin") return "admin";
  return "owner";
}

export function normalizeProfile(user: AuthResponse["data"] | null) {
  if (!user) return null;
  return {
    id: user.id,
    full_name: user.fullName,
    email: user.email,
    phone: null,
    location: null,
    avatar_url: null,
    bio: null,
  };
}

export async function login(email: string, password: string) {
  const response = await apiPost<AuthResponse>("/api/auth/login", { email, password });
  setApiToken(response.token);
  return response;
}

export async function register(
  fullName: string,
  email: string,
  password: string,
  role: "owner" | "vet" | "admin",
) {
  const backendRole = role === "vet" ? "veterinarian" : role === "admin" ? "admin" : "pet_owner";
  const response = await apiPost<AuthResponse>("/api/auth/register", {
    fullName,
    email,
    password,
    role: backendRole,
  });
  setApiToken(response.token);
  return response;
}

export async function fetchMe() {
  return apiGet<{ success: boolean; data: { id: string; fullName: string; email: string; role: string } }>(
    "/api/auth/me",
  );
}

export function logout() {
  setApiToken(null);
}
