import { apiGet } from "./client";
import { format, parseISO, startOfMonth, subMonths } from "date-fns";

export interface AdminStats {
  totalUsers: number;
  activeVets: number;
  appointmentsThisMonth: number;
  pendingVerifications: number;
  userGrowth: { m: string; users: number }[];
}

function safeParse(value: unknown): Date | null {
  if (!value || typeof value !== "string") return null;
  try {
    return parseISO(value);
  } catch {
    return null;
  }
}

export async function fetchAdminStats(): Promise<AdminStats> {
  const [vets, appointments] = await Promise.all([
    apiGet<any[]>("/api/vets").catch(() => []),
    apiGet<any[]>("/api/appointments").catch(() => []),
  ]);

  const vetList = vets ?? [];
  const apptList = appointments ?? [];

  const activeVets = vetList.filter((v) => v.available).length;
  const pendingVerifications = vetList.filter((v) => !v.available).length;

  const monthStart = startOfMonth(new Date());
  const appointmentsThisMonth = apptList.filter((a) => {
    const created = safeParse(a.created_at) ?? safeParse(a.scheduled_at);
    return created ? created >= monthStart : false;
  }).length;

  // Approximate platform users from unique owners referenced across data.
  const ownerIds = new Set<string>();
  for (const a of apptList) if (a.owner_id) ownerIds.add(String(a.owner_id));
  for (const v of vetList) if (v.user_id) ownerIds.add(String(v.user_id));
  const totalUsers = ownerIds.size;

  const now = new Date();
  const userGrowth = Array.from({ length: 6 }, (_, i) => {
    const month = subMonths(now, 5 - i);
    const label = format(month, "MMM");
    const start = startOfMonth(subMonths(now, 5 - i));
    const end = startOfMonth(subMonths(now, 4 - i));
    const count = apptList.filter((a) => {
      const created = safeParse(a.created_at);
      return created ? created >= start && created < end : false;
    }).length;
    return { m: label, users: count };
  });

  return {
    totalUsers,
    activeVets,
    appointmentsThisMonth,
    pendingVerifications,
    userGrowth,
  };
}
