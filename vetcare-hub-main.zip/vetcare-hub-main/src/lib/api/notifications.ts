import { apiGet } from "./client";
import { asStatusTone, type StatusTone } from "@/lib/status";

export interface NotificationView {
  id: string;
  title: string;
  desc: string;
  tone: StatusTone;
  read: boolean;
}

function toNotificationView(row: any): NotificationView {
  return {
    id: row.id,
    title: row.title,
    desc: row.description ?? "",
    tone: asStatusTone(row.tone),
    read: row.read ?? false,
  };
}

export async function fetchNotifications(userId: string): Promise<NotificationView[]> {
  const data = await apiGet<any[]>(`/api/notifications?user_id=${encodeURIComponent(userId)}`);
  return (data ?? []).slice(0, 10).map(toNotificationView);
}
