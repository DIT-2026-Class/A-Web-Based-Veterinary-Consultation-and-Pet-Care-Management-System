// Local data types for the Node.js (Express) backend.
// These replace the previously auto-generated Supabase types so the frontend
// has no dependency on any Supabase integration.

export interface VetRow {
  id: string;
  name: string;
  specialization: string;
  experience_years: number;
  rating: number | string;
  reviews_count: number;
  location: string | null;
  photo: string | null;
  available: boolean;
  bio: string | null;
  consultation_fee: number;
  user_id: string | null;
}

export type VetUpdate = Partial<Omit<VetRow, "id">>;

export interface PetRow {
  id: string;
  owner_id: string;
  name: string;
  species: string;
  breed: string | null;
  age: string | null;
  weight: string | null;
  gender: string | null;
  photo: string | null;
  health_status: string | null;
  health_label: string | null;
  created_at?: string;
}

export type PetInsert = {
  name: string;
  species: string;
  breed?: string | null;
  age?: string | null;
  weight?: string | null;
  gender?: string | null;
  photo?: string | null;
  health_status?: string | null;
  health_label?: string | null;
};
