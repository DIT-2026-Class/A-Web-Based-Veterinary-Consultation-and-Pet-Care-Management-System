import { format, formatDistanceToNow, parseISO } from "date-fns";

const DEFAULT_PHOTO =
  "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=400&q=80";

export function formatDate(value: string | Date): string {
  const d = typeof value === "string" ? parseISO(value) : value;
  return format(d, "MMM d, yyyy");
}

export function formatTime(value: string | Date): string {
  const d = typeof value === "string" ? parseISO(value) : value;
  return format(d, "h:mm a");
}

export function formatRelative(value: string | Date): string {
  const d = typeof value === "string" ? parseISO(value) : value;
  return formatDistanceToNow(d, { addSuffix: true });
}

export function photoOrDefault(photo: string | null | undefined): string {
  return photo || DEFAULT_PHOTO;
}
