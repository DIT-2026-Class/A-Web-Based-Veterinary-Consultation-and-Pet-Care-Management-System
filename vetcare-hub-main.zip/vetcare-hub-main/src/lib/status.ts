export type StatusTone = "success" | "warning" | "info" | "muted" | "error";

export const toneClasses: Record<StatusTone, string> = {
  success: "bg-success/15 text-success border-success/20",
  warning: "bg-warning/15 text-warning border-warning/20",
  info: "bg-info/15 text-info border-info/20",
  error: "bg-destructive/15 text-destructive border-destructive/20",
  muted: "bg-muted text-muted-foreground border-border",
};

export function asStatusTone(value: string | null | undefined): StatusTone {
  const tones: StatusTone[] = ["success", "warning", "info", "muted", "error"];
  return tones.includes(value as StatusTone) ? (value as StatusTone) : "muted";
}
