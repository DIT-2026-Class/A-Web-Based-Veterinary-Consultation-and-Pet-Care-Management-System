export const queryKeys = {
  pets: (ownerId?: string) => ["pets", ownerId] as const,
  appointments: (scope?: string) => ["appointments", scope] as const,
  medicalRecords: (ownerId?: string) => ["medical-records", ownerId] as const,
  vets: () => ["vets"] as const,
  vetByUser: (userId?: string) => ["vet-by-user", userId] as const,
  articles: () => ["articles"] as const,
  notifications: (userId?: string) => ["notifications", userId] as const,
  adminStats: () => ["admin-stats"] as const,
};
