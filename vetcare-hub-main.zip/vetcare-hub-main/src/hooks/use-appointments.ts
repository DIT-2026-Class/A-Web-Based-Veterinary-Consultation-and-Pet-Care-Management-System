import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createAppointment,
  fetchOwnerAppointments,
  fetchVetAppointments,
  updateAppointmentStatus,
  type AppointmentStatus,
} from "@/lib/api/appointments";
import { queryKeys } from "@/lib/query-keys";
import { useAuth } from "@/lib/auth";
import { fetchVetByUserId } from "@/lib/api/vets";

export function useOwnerAppointments() {
  const { user } = useAuth();
  return useQuery({
    queryKey: queryKeys.appointments(`owner-${user?.id}`),
    queryFn: () => fetchOwnerAppointments(user!.id),
    enabled: !!user,
  });
}

export function useVetAppointments() {
  const { user } = useAuth();
  return useQuery({
    queryKey: queryKeys.appointments(`vet-${user?.id}`),
    queryFn: async () => {
      const vet = await fetchVetByUserId(user!.id);
      if (!vet) return [];
      return fetchVetAppointments(vet.id);
    },
    enabled: !!user,
  });
}

export function useCreateAppointment() {
  const { user } = useAuth();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: (input: Parameters<typeof createAppointment>[1]) =>
      createAppointment(user!.id, input),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: queryKeys.appointments(`owner-${user?.id}`) });
      qc.invalidateQueries({ queryKey: queryKeys.appointments(`vet-${user?.id}`) });
    },
  });
}

export function useUpdateAppointmentStatus() {
  const { user } = useAuth();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: ({ id, status }: { id: string; status: AppointmentStatus }) =>
      updateAppointmentStatus(id, status),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: queryKeys.appointments(`owner-${user?.id}`) });
      qc.invalidateQueries({ queryKey: queryKeys.appointments(`vet-${user?.id}`) });
    },
  });
}
