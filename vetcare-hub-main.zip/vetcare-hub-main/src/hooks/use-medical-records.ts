import { useQuery } from "@tanstack/react-query";
import {
  fetchMedicalRecords,
  fetchPetMedicalRecords,
  fetchVaccinationRecords,
} from "@/lib/api/medical-records";
import { queryKeys } from "@/lib/query-keys";
import { useAuth } from "@/lib/auth";

export function useMedicalRecords() {
  const { user } = useAuth();
  return useQuery({
    queryKey: queryKeys.medicalRecords(user?.id),
    queryFn: () => fetchMedicalRecords(user!.id),
    enabled: !!user,
  });
}

export function usePetMedicalRecords(petId: string | undefined) {
  return useQuery({
    queryKey: ["pet-records", petId],
    queryFn: () => fetchPetMedicalRecords(petId!),
    enabled: !!petId,
  });
}

export function useVaccinationRecords(petId: string | undefined) {
  return useQuery({
    queryKey: ["vaccination-records", petId],
    queryFn: () => fetchVaccinationRecords(petId!),
    enabled: !!petId,
  });
}
