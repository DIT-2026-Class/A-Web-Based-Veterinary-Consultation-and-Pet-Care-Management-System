import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { fetchVetByUserId, fetchVets, toggleVetAvailability, updateVet } from "@/lib/api/vets";
import { queryKeys } from "@/lib/query-keys";
import { useAuth } from "@/lib/auth";
import type { VetUpdate } from "@/lib/api/db-types";

export function useVets() {
  return useQuery({
    queryKey: queryKeys.vets(),
    queryFn: fetchVets,
  });
}

export function useCurrentVet() {
  const { user } = useAuth();
  return useQuery({
    queryKey: queryKeys.vetByUser(user?.id),
    queryFn: () => fetchVetByUserId(user!.id),
    enabled: !!user,
  });
}

export function useUpdateVet() {
  const { user } = useAuth();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: VetUpdate }) =>
      updateVet(id, updates),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: queryKeys.vets() });
      qc.invalidateQueries({ queryKey: queryKeys.vetByUser(user?.id) });
    },
  });
}

export function useToggleVetAvailability() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: ({ id, available }: { id: string; available: boolean }) =>
      toggleVetAvailability(id, available),
    onSuccess: () => qc.invalidateQueries({ queryKey: queryKeys.vets() }),
  });
}
