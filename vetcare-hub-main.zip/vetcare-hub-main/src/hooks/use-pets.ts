import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createPet, fetchPets, type PetView } from "@/lib/api/pets";
import { queryKeys } from "@/lib/query-keys";
import { useAuth } from "@/lib/auth";

export function usePets() {
  const { user } = useAuth();
  return useQuery({
    queryKey: queryKeys.pets(user?.id),
    queryFn: () => fetchPets(user!.id),
    enabled: !!user,
  });
}

export function useCreatePet() {
  const { user } = useAuth();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: (input: Parameters<typeof createPet>[1]) => createPet(user!.id, input),
    onSuccess: (newPet) => {
      // Show the new pet immediately, then reconcile with the server.
      qc.setQueryData<PetView[]>(queryKeys.pets(user?.id), (prev) => {
        const existing = prev ?? [];
        if (existing.some((p) => p.id === newPet.id)) return existing;
        return [newPet, ...existing];
      });
      qc.invalidateQueries({ queryKey: queryKeys.pets(user?.id) });
    },
  });
}
