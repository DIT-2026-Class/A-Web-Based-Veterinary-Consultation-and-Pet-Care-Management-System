import { useQuery } from "@tanstack/react-query";
import { fetchArticles } from "@/lib/api/articles";
import { queryKeys } from "@/lib/query-keys";

export function useArticles() {
  return useQuery({
    queryKey: queryKeys.articles(),
    queryFn: fetchArticles,
  });
}
