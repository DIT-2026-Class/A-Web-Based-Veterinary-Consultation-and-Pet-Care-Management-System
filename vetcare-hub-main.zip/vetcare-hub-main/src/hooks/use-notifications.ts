import { useQuery } from "@tanstack/react-query";
import { fetchNotifications } from "@/lib/api/notifications";
import { queryKeys } from "@/lib/query-keys";
import { useAuth } from "@/lib/auth";

export function useNotifications() {
  const { user, loading: authLoading, initialized } = useAuth();

  const userId = user?.id;
  const isReady = initialized && !authLoading && !!userId && userId !== "undefined";

  return useQuery({
    queryKey: queryKeys.notifications(userId),
    queryFn: () => fetchNotifications(userId!),
    enabled: isReady,   // ← only runs when truly ready
    retry: false,
    staleTime: 30_000,
    placeholderData: [], // ← use placeholderData instead of initialData
    //                       placeholderData doesn't trigger a fetch
  });
}