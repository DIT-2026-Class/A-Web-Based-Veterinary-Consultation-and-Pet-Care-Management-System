/**
 * Creates the VetCare system admin via Supabase Auth Admin API.
 * Requires SUPABASE_SERVICE_ROLE_KEY in .env (Supabase Dashboard → Settings → API).
 *
 * Usage: node scripts/create-admin.mjs
 */
import { createClient } from "@supabase/supabase-js";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ADMIN_EMAIL = "admin@vetcareghana.com";
const ADMIN_PASSWORD = "VetCare@Admin2026";
const ADMIN_NAME = "System Admin";

function loadEnv() {
  try {
    const envPath = resolve(__dirname, "../.env");
    const raw = readFileSync(envPath, "utf8");
    for (const line of raw.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eq = trimmed.indexOf("=");
      if (eq === -1) continue;
      const key = trimmed.slice(0, eq).trim();
      let val = trimmed.slice(eq + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (!process.env[key]) process.env[key] = val;
    }
  } catch {
    /* .env optional if vars already set */
  }
}

loadEnv();

const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceKey) {
  console.error(
    "Missing SUPABASE_URL and/or SUPABASE_SERVICE_ROLE_KEY.\n" +
      "Add SUPABASE_SERVICE_ROLE_KEY to .env from Supabase Dashboard → Settings → API.",
  );
  process.exit(1);
}

const admin = createClient(url, serviceKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

const { data: existing } = await admin.auth.admin.listUsers();
const found = existing?.users?.find((u) => u.email === ADMIN_EMAIL);

let userId = found?.id;

if (!userId) {
  const { data, error } = await admin.auth.admin.createUser({
    email: ADMIN_EMAIL,
    password: ADMIN_PASSWORD,
    email_confirm: true,
    user_metadata: { full_name: ADMIN_NAME, role: "owner" },
  });
  if (error) {
    console.error("Failed to create user:", error.message);
    process.exit(1);
  }
  userId = data.user.id;
  console.log("Created auth user:", userId);
} else {
  console.log("Auth user already exists:", userId);
  await admin.auth.admin.updateUserById(userId, { password: ADMIN_PASSWORD });
}

await admin.from("profiles").upsert({
  id: userId,
  full_name: ADMIN_NAME,
  email: ADMIN_EMAIL,
});

await admin.from("user_roles").delete().eq("user_id", userId);
const { error: roleError } = await admin.from("user_roles").insert({
  user_id: userId,
  role: "admin",
});

if (roleError) {
  console.error("Failed to set admin role:", roleError.message);
  process.exit(1);
}

console.log("\n✅ Admin account ready\n");
console.log("  Email:   ", ADMIN_EMAIL);
console.log("  Password:", ADMIN_PASSWORD);
console.log("  Login:   /login → redirects to /admin\n");
